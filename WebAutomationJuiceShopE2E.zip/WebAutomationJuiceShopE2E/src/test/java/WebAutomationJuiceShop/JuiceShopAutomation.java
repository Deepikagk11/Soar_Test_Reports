
package WebAutomationJuiceShop;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JuiceShopAutomation {

	WebDriverWait wait;
	HomePage homePage;
	LoginPage loginPage;
	ProductPage productPage;
	BasketPage basketPage;
	CheckOutPage checkOut;

	WebDriver driver;

	Product product;
	RegistrationPage registrationPage;

	@BeforeClass
	public void setup() {

		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.manage().window().maximize();

		homePage = new HomePage(driver, wait);

		product = new Product(driver, wait);
		registrationPage = new RegistrationPage(driver);
		loginPage = new LoginPage(driver);
		productPage = new ProductPage(driver);
		basketPage = new BasketPage(driver);
		checkOut = new CheckOutPage(driver);
	}

	@Test(priority = 1)
	public void task1_DisplayAllItems() throws InterruptedException {
		homePage.navigateToHomePage();

		homePage.scrollToEndOfPage();
		homePage.setItemsPerPageToMaximum("48");
		assertTrue(homePage.isAllItemsDisplayed(), "All items should be displayed.");
	}

	@Test(priority = 2)
	public void task2_ProductPopupAndReview() throws InterruptedException {
		product.clickOnProduct();

		Assert.assertTrue(product.isProductPopupDisplayed(), "Product popup did not appear.");

		product.expandReview();

		product.closeProductPopup();
	}

	@Test(priority = 3)
	public void task3_Registration() throws InterruptedException {
		registrationPage.navigateToHomePage();

		registrationPage.register("test@gmail.com", "password@1", "password@1");

	}

	@Test(priority = 4)
	public void task4_Lgin() throws InterruptedException {
		String testEmail = "test1@gmail.com";
		String testPassword = "Best@123";

		driver.get("https://juice-shop.herokuapp.com/#/login");
		loginPage.login(testEmail, testPassword);
		productPage.addToBasketButtons(5);

		basketPage.basketPage();
		driver.get("https://juice-shop.herokuapp.com/#/basket");
		checkOut.addAddress();

	}
}
