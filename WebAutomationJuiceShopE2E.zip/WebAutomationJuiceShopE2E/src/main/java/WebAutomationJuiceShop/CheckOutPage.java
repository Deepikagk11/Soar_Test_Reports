package WebAutomationJuiceShop;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckOutPage {

	 WebDriver driver;
	 
	 @FindBy(id="checkoutButton")
	 WebElement checkOut;

	 @FindBy(xpath="//button[@aria-label='Add a new address']")
	 WebElement addNewAddressButton;
	 
	
	 
	 
	 public CheckOutPage(WebDriver driver) {
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }
	  public void addAddress() {
		  
		  checkOut.click();
        addNewAddressButton.click();
//	        addressField.sendKeys(address);
//	        submitAddressButton.click();
	    }
// public void addAddress(String address) {
//		  
//		  checkOut.click();
////	        addNewAddressButton.click();
////	        addressField.sendKeys(address);
////	        submitAddressButton.click();
//	    }
	 
	 

//	    @FindBy(id = "add-new-address")
//	    WebElement addNewAddressButton;
//
//	    @FindBy(id = "address")
//	    WebElement addressField;
//
//	    @FindBy(id = "submit-button")
//	    WebElement submitAddressButton;
//
//	    @FindBy(css = "button.delivery-option")
//	    WebElement deliveryOptionButton;
//
//	    @FindBy(css = "button#checkout")
//	    WebElement checkoutButton;
//
//	    @FindBy(css = "button.add-card")
//	    WebElement addCardButton;
//
//	    @FindBy(id = "card-number")
//	    WebElement cardNumberField;
//
//	    @FindBy(id = "card-expiry")
//	    WebElement cardExpiryField;
//
//	    @FindBy(id = "card-cvv")
//	    WebElement cardCvvField;
//
//	    @FindBy(id = "submit-payment")
//	    WebElement submitPaymentButton;
//
	   
//
//	  
//
//	    public void selectDeliveryMethod() {
//	        deliveryOptionButton.click();
//	    }
//
//	    public void addCreditCard(String cardNumber, String expiry, String cvv) {
//	        addCardButton.click();
//	        cardNumberField.sendKeys(cardNumber);
//	        cardExpiryField.sendKeys(expiry);
//	        cardCvvField.sendKeys(cvv);
//	        submitPaymentButton.click();
//	    }

}
