package WebAutomationJuiceShop;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Product {

	WebDriver driver;
	WebDriverWait wait;

	public Product(WebDriver driver, WebDriverWait wait) {
		this.driver = driver;
		this.wait = wait;
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "img[alt='Apple Juice (1000ml)']")
	WebElement productImage;

	@FindBy(xpath = "img[alt='Apple Juice (1000ml)']")
	WebElement productPopup;

	@FindBy(xpath = "//span[text()=' Reviews ']//ancestor::button")
	WebElement reviewButton;

	@FindBy(xpath = "//button[@aria-label='Close Dialog']")
	WebElement closeButton;

	public void clickOnProduct() {

		productImage.click();

	}

	public void expandReview() {
		wait.until(ExpectedConditions.elementToBeClickable(reviewButton)).click();

	}

	public boolean isProductPopupDisplayed() {
		wait.until(ExpectedConditions.visibilityOf(productPopup));
		return productPopup.isDisplayed();

	}

	public void closeProductPopup() {
		wait.until(ExpectedConditions.elementToBeClickable(closeButton)).click();
	}

}