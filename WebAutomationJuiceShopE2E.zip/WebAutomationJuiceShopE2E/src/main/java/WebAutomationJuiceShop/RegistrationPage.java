package WebAutomationJuiceShop;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPage {
//	
//	By usernameField = By.id("username");
//    By passwordField = By.id("password");
//    By loginButton = By.id("login-button");
//    By errorMessage = By.id("error-message");

	@FindBy(id = "emailControl")
	WebElement usernameField;

	@FindBy(id = "passwordControl")
	WebElement passwordField;
	@FindBy(id = "repeatPasswordControl")
	WebElement repeatPassword;
	@FindBy(css = ".mat-slide-toggle-bar")
	WebElement showPasswordAdwise;

	@FindBy(css = ".mat-form-field-infix.ng-tns-c21-12")
	WebElement dropDown;

	WebDriver driver;

	// Constructor
	public RegistrationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this); 
	}

	public void register(String username, String password, String repeatPwd) {
		usernameField.sendKeys(username);
		passwordField.sendKeys(password);
		repeatPassword.sendKeys(repeatPwd);
		showPasswordAdwise.click();
		dropDown.sendKeys("ade");

		// clickLoginButton();
		// return new HomePage(driver); // Return HomePage object after successful login
	}

	public void navigateToHomePage() throws InterruptedException {
		driver.get("https://juice-shop.herokuapp.com/#/register");

	}

}
