package WebAutomationJuiceShop;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;

public class HomePage {

	WebDriver driver;
	WebDriver wait;

	@FindBy(css = ".mat-select-arrow-wrapper.ng-tns-c30-14")
	WebElement itemsPerPageDropdown;

	@FindBy(css = "div.mat-grid-tile")
	WebElement allItemsContainer;

	@FindBy(xpath = "//span[text()='Dismiss']")
	WebElement dismiss;

	@FindBy(xpath = "//a[text()='Me want it!']")
	WebElement meWant;

	public HomePage(WebDriver driver, WebDriverWait wait) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void scrollToEndOfPage() {

		WebElement scrollableElement = driver
				.findElement(By.cssSelector(".mat-drawer-content.mat-sidenav-content.ng-star-inserted"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollBy(0, 1500);", scrollableElement);
		System.out.println("print test");
	}

	public void setItemsPerPageToMaximum(String value) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
		wait.until(ExpectedConditions.elementToBeClickable(itemsPerPageDropdown)).click();
		// itemsPerPageDropdown.click();
		WebElement option = driver.findElement(By.xpath("//span[normalize-space()='" + value + "']"));
		option.click();
	}

	public boolean isAllItemsDisplayed() {

		int expectedItemCount = 48;
		int actualItemCount = driver.findElements(By.cssSelector("div.mat-grid-tile")).size();
		return actualItemCount == expectedItemCount;
	}

	public void navigateToHomePage() throws InterruptedException {
		driver.get("https://juice-shop.herokuapp.com/#/");
		// Thread.sleep(200);
		dismiss.click();
		meWant.click();
	}
}
