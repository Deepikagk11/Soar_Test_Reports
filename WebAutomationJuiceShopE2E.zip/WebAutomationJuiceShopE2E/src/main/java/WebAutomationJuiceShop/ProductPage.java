package WebAutomationJuiceShop;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class ProductPage {
	WebDriver driver;

	@FindBy(css = "mat-card")
	List<WebElement> products;

	@FindBy(css = "button[aria-label='Add to Basket']")
	List<WebElement> addToBasketButtons;

	@FindBy(css = "span.mat-badge-content")
	WebElement cartBadge;

	@FindBy(css = "snack-bar-container")
	WebElement successPopup;

	public ProductPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public int getCartCount() {
		return Integer.parseInt(cartBadge.getText());
	}

	public void addToBasketButtons(int count) {
		for (int i = 0; i < count && i < addToBasketButtons.size(); i++) {
			addToBasketButtons.get(i).click();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			wait.until(ExpectedConditions.visibilityOf(successPopup));
			Assert.assertTrue(successPopup.isDisplayed(), "Success popup not displayed!");
		}

	}

}
