package WebAutomationJuiceShop;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BasketPage {

	WebDriver driver;

	@FindBy(xpath = "//button[.//span[contains(text(),'Your Basket')]]")
	WebElement basket;

	public BasketPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

//	    public void increaseQuantityOfFirstProduct() {
//	        increaseQuantityButton.click();
//	    }
//
//	    public void removeFirstProduct() {
//	        removeItemButton.click();
//	    }
//
//	    public double getTotalPrice() {
//	        return Double.parseDouble(totalPrice.getText().replace("$", ""));
//	    }

	public void basketPage() {
		basket.click();
	}
}